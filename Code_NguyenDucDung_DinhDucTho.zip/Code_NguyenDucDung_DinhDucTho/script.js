
document.getElementById('xemThem').addEventListener('click', function(event) {
    event.preventDefault();
    var subMenuContainer = document.querySelector('.subMenuContainer');
    if (subMenuContainer.style.display === 'none' || subMenuContainer.style.display === '') {
        subMenuContainer.style.display = 'block';
    } else {
        subMenuContainer.style.display = 'none';
    }
});


let currentIndex = 0;
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');

function updateSlidePosition() {
    slides.forEach((slide, index) => {
        slide.style.transform = `translateX(${(index - currentIndex) * 310}px)`;
    });
    dots.forEach(dot => dot.classList.remove('active'));
    dots[currentIndex].classList.add('active');
}

function moveToNextSlide() {
    currentIndex = (currentIndex < slides.length - 1) ? currentIndex + 1 : 0;
    updateSlidePosition();
}

dots.forEach(dot => {
    dot.addEventListener('click', function() {
        currentIndex = parseInt(dot.getAttribute('data-index'));
        updateSlidePosition();
    });
});


setInterval(moveToNextSlide, 3000);

updateSlidePosition();
